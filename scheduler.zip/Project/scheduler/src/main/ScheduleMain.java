package main;

import java.util.Scanner;

import controller.MonGantt;
import controller.Roster;
import controller.Schedule;
import view.SchedulerUi;

public class ScheduleMain {

	public static void main(String[] args) {
		int menu;
		Scanner sc=new Scanner(System.in);
		Schedule handler=new Schedule();
		SchedulerUi show=new SchedulerUi();
		MonGantt mon = new MonGantt();
		Roster ro = new Roster();
		
		while(true){
			show.ShowMenu();	//기본메뉴 표시
			menu=Integer.parseInt(sc.nextLine());
			
			switch(menu){	//기본 메뉴
			case 1:	//스케줄 등록
				show.ScheduleInsertMenu();
			
				menu=Integer.parseInt(sc.nextLine());
				
				switch(menu){//스케줄에 따른 등록메뉴
				case 1:	//개인 스케줄 등록
					show.UserMenu();
					menu=Integer.parseInt(sc.nextLine());
					switch(menu){
					case 1:	//유저등록
						handler.UserInsert();
						break;
					case 2:	//스케줄 추가
						show.WorkInsertMenu();
						menu=Integer.parseInt(sc.nextLine());
						
						switch(menu){
						case 1:	// 월 스케줄 등록
							handler.MonthWorkInsert();
							break;
						case 2:	//일 스케줄 등록
							handler.DayWorkinsert();
							break;
						case 3:	//취소
							break;
						default:
							System.out.println("입력이 잘못 되었습니다.");
							break;	
						}
						break;
					case 3:	//취소
						break;
					default:
						System.out.println("입력이 잘못 되었습니다.");
						break;	
					}
					break;
				case 2:	//근무표 등록
					ro.chart();
					break;
				case 3:	//프로젝트 등록
					mon.insert();
					break;
				case 4:	//취소
					continue;
				default:
					System.out.println("입력이 잘못 되었습니다.");
					break;	
				}
					break;
			case 2:	//스케줄 검색
				show.ScheduleSearchMenu();
				menu=Integer.parseInt(sc.nextLine());
				switch(menu){
				case 1: 
					show.WorkSearchMenu();
					menu=Integer.parseInt(sc.nextLine());
					switch(menu){
					case 1:	//월 스케줄 검색 
						handler.MonthWorkSearch();
						break;
					case 2:	//일 스케줄 검색
						handler.DayWorkSearch();
						break;
					case 3:	//취소
						continue;
					default:
						System.out.println("입력이 잘못 되었습니다.");
						break;	
					}
					break;
				case 2:
					
					break;
				case 3:
					mon.search();
					break;
				case 4:
					break;
				default:
					System.out.println("입력이 잘못 되었습니다.");
					break;
				}
				break;
			case 3:	//스케줄 수정
				show.ScheduleUpdateMenu();
				menu=Integer.parseInt(sc.nextLine());
				switch(menu){
				case 1:
					show.WorkUpdateMenu();
					menu=Integer.parseInt(sc.nextLine());
					switch(menu){
					case 1:	//월 스케줄 수정 
						handler.MonthWorkUpdate();
						break;
					case 2:	//일 스케줄 수정
						handler.DayWorkUpdate();
					break;
					case 3:	//취소
						continue;
					default:
						System.out.println("입력이 잘못 되었습니다.");
						break;	
					}
					break;
				case 2:
					break;
				case 3: // 프로젝트 수정
					mon.update();
					break;
				case 4:
					break;
				default:
					System.out.println("입력이 잘못 되었습니다.");
					break;
				}
				break;
			case 4:	//스케줄 삭제
				show.ScheduleDeleteMenu();
				menu=Integer.parseInt(sc.nextLine());
				
				switch(menu){
				case 1:	//개인 스케줄 삭제
					show.UserSearchMenu();
					menu=Integer.parseInt(sc.nextLine());
					
					switch(menu){
					case 1:	//유저 선택
						show.WorkDeleteMenu();
						menu=Integer.parseInt(sc.nextLine());
						
						switch(menu){
						case 1:	//월 스케줄 삭제
							handler.MonthworkDelete();
							break;
						case 2:	//일 스케줄 삭제
							handler.DayworkDelete();
						break;
						case 3:	//취소
							continue;
						default:
							System.out.println("입력이 잘못 되었습니다.");
							break;	
						}
						break;
					case 2:	//취소
						continue;
					default:
						System.out.println("입력이 잘못 되었습니다.");
						break;	
					}
					break;
				case 2:	//근무표 삭제
					break;
				case 3:	//프로젝트 삭제
					mon.delete();
					break;
				case 4:
					break;
				default:
					System.out.println("입력이 잘못 되었습니다.");
					break;	
				}
				break;
			case 5:
				System.out.println("프로그램이 종료 되었습니다.");
				System.exit(0);
			default:
				System.out.println("입력이 잘못 되었습니다.");
				break;
			}
		}

	}

}
