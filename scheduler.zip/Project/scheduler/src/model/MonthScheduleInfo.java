package model;
/*
 * 월 일정을 저장하는 클래스
 */
public class MonthScheduleInfo {
	private String mwork;	//일정내용
	private int startday;	//시작일
	private int endday;		//종료일
	private int month;		//달
	private int year;		//년
	
	
	public MonthScheduleInfo(int year,int month,String mwork, int startday, int endday) {
		super();
		this.year=year;
		this.month=month;
		this.mwork = mwork;
		this.startday = startday;
		this.endday = endday;
	}
	@Override
	public String toString() {
		return "[년도=" + year + ", 월=" + month + ", 시작일=" + startday + ", 종료일="
				+ endday + ", 일정=" + mwork + "]";
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public int getMonth() {
		return month;
	}
	public void setMonth(int month) {
		this.month = month;
	}
	public String getMwork() {
		return mwork;
	}
	public void setMwork(String mwork) {
		this.mwork = mwork;
	}
	public int getStartday() {
		return startday;
	}
	public void setStartday(int startday) {
		this.startday = startday;
	}
	public int getEndday() {
		return endday;
	}
	public void setEndday(int endday) {
		this.endday = endday;
	}
}
