package model;

import java.util.ArrayList;

public class Title1 {
	
	private String title1;
	private String SSday;
	private String FFday;
	public ArrayList<MonthGanttInfo> mgantt = new ArrayList<MonthGanttInfo>();
	
	public Title1(String title1){
		this.title1= title1;
		
	}
	
	
	public String getSSday() {
		return SSday;
	}


	public void setSSday(String sSday) {
		SSday = sSday;
	}


	public String getFFday() {
		return FFday;
	}


	public void setFFday(String fFday) {
		FFday = fFday;
	}


	public String getTitle1() {
		return title1;
	}
	public void setTitle1(String title1) {
		this.title1 = title1;
	}

	
}
