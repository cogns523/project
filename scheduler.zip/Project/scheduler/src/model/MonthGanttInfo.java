package model;

import java.util.ArrayList;

public class MonthGanttInfo {
	private String job;			//할일
	private String fdate;			//언제부터
	private String ldate;			//언제까지
	private String jobday; 			//일정에 따라 "  "+## 저장
	
	public MonthGanttInfo(String job, String fdate, String ldate, String jobday) {
		super();
		this.job = job;
		this.fdate = fdate;
		this.ldate = ldate;
		this.jobday = jobday;
	}
	
	
	@Override
	public String toString() {
		return "[일정=" + job + ", 일정 시작 일=" + fdate + ", 일정 종료 일=" + ldate + "]";
	}
	public String getJob() {
		return job;
	}
	public void setJob(String job) {
		this.job = job;
	}
	public String getFdate() {
		return fdate;
	}
	public void setFdate(String fdate) {
		this.fdate = fdate;
	}
	public String getLdate() {
		return ldate;
	}
	public void setLdate(String ldate) {
		this.ldate = ldate;
	}
	public String getJobday() {
		return jobday;
	}
	public void setJobday(String jobday) {
		this.jobday = jobday;
	}
}
