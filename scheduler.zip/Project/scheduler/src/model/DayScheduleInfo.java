package model;

import java.util.ArrayList;

public class DayScheduleInfo {

	public String fdate;
	public String ldate;
	int hour;				//시작시
	int minute;				//시작분
	int hourl;					//끝날시
	int minutel;				//끝날분
	String job;
	String jobday;
	
	public DayScheduleInfo(int hour, int minute, int hourl, int minutel, String job) {
		super();
		this.job = job;
		this.hour = hour;
		this.minute = minute;
		this.hourl = hourl;
		this.minutel = minutel;
	}
	public String getJob() {
		return job;
	}
	public void setJob(String job) {
		this.job = job;
	}

	public String getFdate() {
		return fdate;
	}
	public void setFdate(String fdate) {
		this.fdate = fdate;
	}
	public String getLdate() {
		return ldate;
	}
	public void setLdate(String ldate) {
		this.ldate = ldate;
	}
	public String getJobday() {
		return jobday;
	}
	public void setJobday(String jobday) {
		this.jobday = jobday;
	}
	public int getHour() {
		return hour;
	}
	public void setHour(int hour) {
		this.hour = hour;
	}
	public int getMinute() {
		return minute;
	}
	public void setMinute(int minute) {
		this.minute = minute;
	}
	public int getHourl() {
		return hourl;
	}
	public void setHourl(int hourl) {
		this.hourl = hourl;
	}
	public int getMinutel() {
		return minutel;
	}
	public void setMinutel(int minutel) {
		this.minutel = minutel;
	}
	@Override
	public String toString() {
		return "[시작 시간=" + fdate + ", 종료시간=" + ldate +" 할일=" + job + "]";
	}
}
