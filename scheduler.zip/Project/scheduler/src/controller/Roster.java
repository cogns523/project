package controller;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Scanner;

public class Roster {
	public void chart(){
		Scanner sc= new Scanner(System.in);
		Calendar cal = Calendar.getInstance(); //캘린더 인스턴스 얻기
		String[] name;
		String rt;
		String fi;
		
		while(true){
		System.out.println("=====근무표 등록을 시작합니다.=====");
		System.out.println("어떤 근무표를 작성하실 것입니까 ? ");
		rt = sc.nextLine();
		System.out.println("언제 근무표입니까 ?     ex)2018.5"); 
		fi = sc.nextLine();
		System.out.println("근무자는 몇명입니까?  (최소 3명, 최대 5명)");
		int nameget = Integer.parseInt(sc.nextLine());
		name = new String[nameget];
		
		System.out.println("근무자 이름을 입력해주세요 : ");
		for(int i=0;i<nameget;i++){name[i] = sc.nextLine();}
		
		String[] time = new String[name.length];
		
		if(name.length >= 3 && name.length <= 5){
			System.out.println("등록을 완료했습니다.");
			break;
		}
		System.out.println("사람 수를 잘못입력하셨습니다.");
		}
		 
		ArrayList time = new ArrayList();
		
		
		if(name.length == 5){
			time.add("AM");
			time.add("PM");
			time.add("N");
			time.add("N2");
			time.add("OFF");
		}else if(name.length == 4){
			time.add("AM");
			time.add("PM");
			time.add("N");
			time.add("OFF");
		}else{
			time.add("AM");
			time.add("PM");
			time.add("OFF");
			}
        
        
        
		ArrayList list = new ArrayList();
       
        int to = (24*60)/(name.length-1);		//하루에서 휴일자를 제외한 시간을 나누기
      
        int h = to/60;			//나눈 시간을 다시 한명이 해야 될 시로 바꿈
        int m = to%60;			//나눈 시간을 다시 한명이 해야 될 분으로 바꿈
		
        String[] test = new String[name.length];		//사람수에 따라 나눈 시간을 다시 한배열안에 넣음
        int hours = 6;
        int minutes = 0;
        
       
        
        for(int i =0;i<test.length;i++){
        	String strat = hours+"시"+ minutes+"분";
        	
        	hours += h;
        	if(hours >= 24){
        		hours -=24;
        	}
        	minutes += m;
        	String end = (hours)+"시"+(minutes)+"분";
        	test[i] = strat +"~"+ end;
        	
        	
        	
        	if(i == test.length-1) test[i] = "휴일";
        }
      
        
                                                                                           
		
		String[] splfi = fi.split("\\."); 
		cal.set(Calendar.YEAR,Integer.parseInt(splfi[0]));			//년
		cal.set(Calendar.MONTH,Integer.parseInt(splfi[1])-1);			//월
		
		
        int endDate = cal.getActualMaximum(Calendar.DATE); //달의 마지막일 얻기
        int tmp = 0;
        
        
        for(int j = 0;j<name.length;j++){
        	String[] test2 = new String[endDate];
        	tmp = 0+j;	
        	for(int i=0;i<test2.length;i++){
        		
        		if( tmp >= test.length){
        			tmp = 0;
        			test2[i] = (String) time.get(tmp);
        		}else{ test2[i] = (String) time.get(tmp);}
	        	++tmp;
        	}
        	list.add(test2);
        }
        
        //달력출력
        for(int i=0;i<time.size();i++){
        System.out.printf("%s : %s  ",time.get(i), test[i]);
        }System.out.println();
        System.out.println("===================================== "+ splfi[0]+"년  " + splfi[1] +"월 =========================================");
        System.out.println();
        System.out.println("===================================== "+rt +"표 출력 ======================================");
        //1일이 시작되는 이전의 요일 공백으로 채우기 
        int x= 0;
        int z =0;
       
        System.out.print("근무자이름|");
        
        for (int i = 1; i <= endDate ; i++) {  	//주차
        	if(i == 11){System.out.print("근무자이름|");}
        	if(i == 21){System.out.print("근무자이름|");}
        	if(i == 31){System.out.print("근무자이름|");}
        	System.out.printf("%5d일\t|",i);
        	if(i%10==0){
        		System.out.println();
        		System.out.println("==========================================================================================");
        		x = i;
        		z = x-9;
        		
        		for(int e=0;e<name.length;e++){
        			
        			
        			System.out.println();
        			System.out.printf("%7s  |",name[e]);
        			String[] text = new String[endDate];
        			text = (String[]) list.get(e);
        			for(int j = z; j <= x;j++){
        				System.out.printf("%5s  |",text[j-1]);
        			}
        
        		}//for j끝
        		System.out.println();
        		System.out.println();}//if끝
        	
        		if(i == 31){
        			System.out.println();
        			System.out.println("=================");
        			for(int e=0;e<name.length;e++){
        
            			System.out.println();
            			System.out.printf(" %7s  |",name[e]);
            			String[] text = new String[endDate];
            			text = (String[]) list.get(e);
            			System.out.printf("%5s  | ",text[i-1]);
            			
        		}
        }//for i끝
       
	}//시작 for문
        
     
    	  
      
}
}

