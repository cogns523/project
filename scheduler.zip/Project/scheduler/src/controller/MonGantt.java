package controller;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Scanner;

import model.MonthGanttInfo;
import model.MonthScheduleInfo;
import model.Title1;

public class MonGantt {
	ArrayList<Title1> title = new ArrayList<Title1>();
	Scanner sc = new Scanner(System.in);
	int cnt;
	int y;				//시작년
	int m;				//월
	int d;				//일
	int yl;				//종료년
	int ml;				//월
	int dl;				//일
	

	public void view(){
		System.out.println(title.toString());
	}
	public void insert(){
		System.out.println("=======================");
		System.out.print("프로젝트 주제를 입력해주세요.>");
		String title1 = sc.nextLine();
		title.add(new Title1(title1));
		
		for(int i=0; i<title.size();i++){
			if(title1.equals(title.get(i).getTitle1())){
				System.out.print("프로젝트의 시작일을 입력해주세요. ex)2017.1.1 .>");
				title.get(i).setSSday(sc.nextLine());
				System.out.print("프로젝트의 종료일을 입력해주세요. ex)2017.3.3 .>");
				title.get(i).setFFday(sc.nextLine());
				
				System.out.print("몇 개의 일정을 등록하시겠습니까? .>");
				int num=Integer.parseInt(sc.nextLine());
				
				for(int j=0; j<num; j++){
					title.get(i).mgantt.add(new MonthGanttInfo("","","",""));
					System.out.print("할 일정이 무엇입니까?.>");
					title.get(i).mgantt.get(j).setJob(sc.nextLine());
					System.out.print("일정을 시작 할 날짜  ex)2017.6.28 .>");
					title.get(i).mgantt.get(j).setFdate(sc.nextLine());
					System.out.print("일정을 종료 할 날짜  ex)2017.9.14 .>");
					title.get(i).mgantt.get(j).setLdate(sc.nextLine());
				}
				System.out.println("**프로젝트 등록이 완료 되었습니다.**");
			}
		}
	}
	
	public void search(){
		
	System.out.println("=========================");
	System.out.print("검색할 프로젝트 주제를 입력해주세요.>");
	String title1 = sc.nextLine();
	String jday="";
	
	for(int k=0; k<title.size(); k++){
		if(title.get(k).getTitle1().equals(title1)){
			

			String fisec = title.get(k).getSSday();
			String[] splfi = fisec.split("\\.");
			

			String losec = title.get(k).getFFday();
			String[] spllo = losec.split("\\.");
			
			int monfi = Integer.parseInt(splfi[1]);
						//최초시작월과 최종완료월 차이값
			int yertest = Math.abs(Integer.parseInt(splfi[0])-Integer.parseInt(spllo[0]));
			int totalmon = Math.abs((Integer.parseInt(spllo[1])+(yertest*12))
												- Integer.parseInt(splfi[1]));
			
			for(int i=0;i < title.get(k).mgantt.size();i++){
				
				String md = "";								//##채우기
				String back = "";							//빈칸채우기
				
				String test = "";							//split사용시 쓸 변수
				
				test = title.get(k).mgantt.get(i).getFdate();
				String[] spl1 = test.split("\\.");				//시작 일정 나눔
				if(spl1.length != 3){
					System.out.println("잘못입력하셨습니다 다시 입력하세요.");
					return;
				}
				
				y = Integer.parseInt(spl1[0]);
				m = Integer.parseInt(spl1[1]);					//시작 월 추출
				d = Integer.parseInt(spl1[2]);					//시작 일 추출
							
				test = title.get(k).mgantt.get(i).getLdate();
				String[] spl2 = test.split("\\.");				//끝 일정 나눔
				if(spl2.length != 3){
					System.out.println("잘못입력하셨습니다 다시 입력하세요.");
					return;
				}
				yl = Integer.parseInt(spl2[0]);
				ml = Integer.parseInt(spl2[1]);					//끝 월 추출
				dl = Integer.parseInt(spl2[2]);					//끝 일 추출
				
				//한개의 일에 시작일 부터 끝날일까지 차이 계산
				int toy = Math.abs(y - yl);
				int tom = Math.abs(m - (ml + (toy*12)));
				int tod = Math.abs(d - (dl + (tom*30)));
				
				int sd = 0;				//"  "와 ##를 얼마큼 넣을지 수를 저장할 변수
				
				for(int j=1;j<=4*(1+tom);j++){		//월의 4주단위로 나눔 (월단위에 따라 j수가 증가)
					if(tod <= 7*j){
						if		(tod <= 2+(7*(j-1)))		sd = 1+(3*(j-1));
						else if	(tod <= 4+(7*(j-1)))		sd = 2+(3*(j-1));
						else if	(tod <= 7+(7*(j-1))) 		sd = 3+(3*(j-1));
					}
					else if (tod >= 28+(30*(j-1)) && tod <= 30*j) sd = 12*j;
					if(sd != 0) break;
				}
				
				for(int j=1;j<=sd;j++){
					md += "##";
				}
				
				int backyer	= Integer.parseInt(splfi[0]);	//최초시작일 삽입
				int backmon	= Integer.parseInt(splfi[1]);	//최초시작월 삽입
				int backday	= Integer.parseInt(splfi[2]);	//최초시작년 삽입
				
				//최초시작일과 시작일에 차이 계산후 넣을 변수
				int btoy = Math.abs(backyer -y);
				int btom = Math.abs(backmon - (m+ (btoy*12)));
				int btod = Math.abs(backday - (d+ (btom*30)));
				
				//최초의시작일이 1이이 아닐시 차이를 매우기위한 변수
				int toba1 = 0;
				if(backday != 1){
					for(int j=1;j<=4;j++){
						if(backday <= 7*j){
							if		(backday <= 2+(7*(j-1)))		toba1 = 0+(3*(j-1));
							else if	(backday <= 4+(7*(j-1)))		toba1 = 1+(3*(j-1));
							else if	(backday <= 7+(7*(j-1))) 		toba1 = 2+(3*(j-1));
						}
						else if (backday >= 28+(j*30) && backday <= 30) toba1 = 12;
						if(toba1 != 0) break;
					}
				}
				
				int toba2 = 0;				//"  "와 ##를 얼마큼 넣을지 수를 저장할 변수
				for(int j=1;j<=4*(1+btom);j++){		//월의 4주단위로 나눔 (월단위에 따라 j수가 증가)
					if(btod <= 7*j){
						if		(btod <= 2+(7*(j-1)))		toba2 = 1+(3*(j-1));
						else if	(btod <= 4+(7*(j-1)))		toba2 = 2+(3*(j-1));
						else if	(btod <= 7+(7*(j-1))) 		toba2 = 3+(3*(j-1));
					}
					else if (btod >= 28+(30*(j-1)) && btod <= 30*j) toba2 = 12*j;
					if(toba2 != 0) break;
				}
				
				for(int j=1;j<=toba1+toba2-1;j++){
					back += "  ";
					}			//주단위에서 #입력
				
				title.get(k).mgantt.get(i).setJobday(back+md);
			}
		
			int[] mon_day = {1,2,3,4};			//월입력시 주단위

			System.out.printf("\t|");
			
			
			for(int i= monfi ;i<(monfi+totalmon)+1;i++){
				if(i > 12){
					System.out.printf("%23d|",i-12);
					continue;
					}
				System.out.printf("%23d|",i);
			}
			System.out.println();
			System.out.printf("  스케줄  \t|");
			for(int j=monfi;j<(monfi+totalmon)+1;j++){
				for(int i=0;i<mon_day.length;i++){
					System.out.printf("%5d|",mon_day[i]);
				}
			}
			System.out.println();
			
			for(int i =0;i<title.get(k).mgantt.size();i++){
				
				System.out.printf("%s\t|%s\n",title.get(k).mgantt.get(i).getJob(),title.get(k).mgantt.get(i).getJobday());
				
				
			}break;
		}
	}
}
	
	public void update(){
		cnt=0;
		System.out.println("=======================");
		System.out.print("수정 할 프로젝트 주제를 입력해주세요.>");
		String title1 = sc.nextLine();
		
		for(int i=0; i<title.size(); i++){	//유저수만큼 반복
			if(title.get(i).getTitle1().equals(title1)){	//이름비교
				for(int j=0;j<title.get(i).mgantt.size();j++){	//일정수만큼 반복
					System.out.println((cnt+1)+"."+title.get(i).mgantt.get(cnt).toString());	//등록된 일정 출력
					cnt++;	//인덱스 증가
				}
			}
		}
		
		System.out.print("수정할 일정번호를 입력하세요.>");
		int num1=Integer.parseInt(sc.nextLine());
		
		for(int i=0; i<title.size();i++){
			if(title1.equals(title.get(i).getTitle1())){

					System.out.print("수정 할 일정.>"+title.get(i).mgantt.get(num1-1).getJob()+"-->");
					title.get(i).mgantt.get(num1-1).setJob(sc.nextLine());
					System.out.print("수정 할 일정을 시작 할 날짜.>"+title.get(i).mgantt.get(num1-1).getFdate()+"-->");
					title.get(i).mgantt.get(num1-1).setFdate(sc.nextLine());
					System.out.print("수정 할 일정을 종료 할 날짜.>"+title.get(i).mgantt.get(num1-1).getLdate()+"-->");
					title.get(i).mgantt.get(num1-1).setLdate(sc.nextLine());
					
				System.out.println("**프로젝트 수정이 완료 되었습니다.**");
				System.out.println(title.get(i).mgantt.toString());
				break;
			}
		}
	}
	
	public void delete(){
		cnt=0;
		System.out.println("=======================");
		System.out.print("삭제 할 프로젝트 주제를 입력해주세요.>");
		String title1 = sc.nextLine();
		
		for(int i=0; i<title.size(); i++){	//유저수만큼 반복
			if(title.get(i).getTitle1().equals(title1)){	//이름비교
				for(int j=0;j<title.get(i).mgantt.size();j++){	//일정수만큼 반복
					System.out.println((cnt+1)+"."+title.get(i).mgantt.get(cnt).toString());	//등록된 일정 출력
					cnt++;	//인덱스 증가
				}
			}
		}
		for(int i=0; i<title.size(); i++){
			if(title.get(i).getTitle1().equals(title1)){
		System.out.print("삭제 할 일정번호를 입력하세요.>");
		int num1=Integer.parseInt(sc.nextLine());
				title.get(i).mgantt.remove(num1-1);	//인덱스에 해당하는 스케줄 삭제
			
				System.out.println(num1+"번째가 프로젝트가 삭제되었습니다.");
				System.out.println("");
			}
			}
		}
	}