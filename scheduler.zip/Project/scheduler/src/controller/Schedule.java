package controller;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Scanner;

import model.DayScheduleInfo;
import model.MonthScheduleInfo;
import model.User;


public class Schedule {

    // 생성자 : 데이터 생성
	int cnt=0;
	Scanner sc=new Scanner(System.in);

	ArrayList<User> Arrayname=new ArrayList<User>();
	
	public void UserInsert(){ //사용자 이름 등록
		
		System.out.println("==유저 등록==");
		System.out.print("이름을 등록하세요>");
		String name=sc.nextLine();
		Arrayname.add(new User(name));
		System.out.println("유저 등록이 완료 되었습니다.");
		System.out.println("");
	}
	
	public void MonthWorkInsert(){
		System.out.println("==달 스케줄 등록==");
		System.out.print("스케줄을 등록할 이름을 입력하세요>");
		String name=sc.nextLine();
	
		for(int i=0; i<Arrayname.size(); i++){
			if(Arrayname.get(i).getName().equals(name)){
				Arrayname.get(i).monthwork.add(new MonthScheduleInfo(0,0,"",0,0));	//객체 생성
				int cnt=Arrayname.get(i).monthwork.size()-1;	//유저에 해당하는 달일정의 인덱스
				
				System.out.print("년도를 입력해주세요>");	//달 일정의 년 등록
				int year = Integer.parseInt(sc.nextLine());
				Arrayname.get(i).monthwork.get(cnt).setYear(year);
				
				System.out.print("달을 입력해주세요>");	//달 일정의 달 등록
				int month = Integer.parseInt(sc.nextLine());
				Arrayname.get(i).monthwork.get(cnt).setMonth(month);
				
				System.out.print("시작일을 입력해주세요>");	//달 일정의 시작일 등록
				int startday =Integer.parseInt(sc.nextLine());
				Arrayname.get(i).monthwork.get(cnt).setStartday(startday);
				
				System.out.print("종료일을 입력해주세요>");	//달 일정의 종료일 등록
				int endday =Integer.parseInt(sc.nextLine());
				Arrayname.get(i).monthwork.get(cnt).setEndday(endday);
				
				System.out.print("할일을 입력해주세요.>");	//달 일정내용 등록
				String mwork=sc.nextLine();
				Arrayname.get(i).monthwork.get(cnt).setMwork(mwork);
				
		
				System.out.println("스케줄 등록이 완료 되었습니다.");
				System.out.println("");
			}
		}
	}
	
	public void DayWorkinsert(){
		System.out.println("===========하루일정 스케줄 등록==========");
		System.out.print("스케줄을 등록할 이름을 입력하세요>");
		String name=sc.nextLine();
		
		for(int i=0; i<Arrayname.size(); i++){

			if(Arrayname.get(i).getName().equals(name)){

				Arrayname.get(i).daywork.add(new DayScheduleInfo(0,0,0,0,""));	//객체 생성
				int cnt=Arrayname.get(i).daywork.size()-1;
				
				System.out.print("시작시간을 입력해주세요 ex)6:30 =");
				Arrayname.get(i).daywork.get(cnt).setFdate(sc.nextLine());
				System.out.print("종료시간을 입력해주세요 ex)8:30 =");
				Arrayname.get(i).daywork.get(cnt).setLdate(sc.nextLine());
				System.out.print("할 일정이 무엇입니까? =");
				Arrayname.get(i).daywork.get(cnt).setJob(sc.nextLine());
								
				System.out.println("스케줄 등록이 완료 되었습니다.");
				System.out.println("");
			}
		}
	}
	
	public void DayWorkSearch(){
		System.out.println("=========================");
		System.out.print("검색할 유저이름을 입력해주세요>");
		String name = sc.nextLine();
		
		for(int d=0; d<Arrayname.size(); d++){
			if(Arrayname.get(d).getName().equals(name)){
				for(int i=0; i < Arrayname.get(d).daywork.size();i++){
					
					String md = "";								//##채우기
					String back = "";							//빈칸채우기
					
					String test = "";							//split사용시 쓸 변수
					
					test = Arrayname.get(d).daywork.get(i).getFdate();
					String[] spl1 = test.split("\\:");				//시작 일정 나눔
					if(spl1.length != 2){
						System.out.println("잘못입력하셨습니다 다시 입력하세요.");
						return;
					}
					
					int fhour = Integer.parseInt(spl1[0]);					//시 추출
					int fminute = Integer.parseInt(spl1[1]);					//분 추출
					
					test = Arrayname.get(d).daywork.get(i).getLdate();
					String[] spl2 = test.split("\\:");				//끝 일정 나눔
					if(spl2.length != 2){
						System.out.println("잘못입력하셨습니다 다시 입력하세요.");
						return;
					}
					int lhour = Integer.parseInt(spl2[0]);					//끝 시 추출
					int lminute = Integer.parseInt(spl2[1]);					//끝 분 추출
					
					//한개의 일에 시작 부터 끝날때까지 차이 계산
					int toh = Math.abs(fhour - lhour);			//차이 시
					int tom = Math.abs(fminute - (lminute + (toh*60)));		//차이 분
					
					
					int sd = 0;				//##를 얼마큼 넣을지 수를 저장할 변수
					
					for(int j=1;j<=12;j++){		//하루를 2시간으로 나눔
						if(tom <= 120*j){			//2시간을 40분단위로 나뉨
							
							if	(tom <= 40+((j-1)*120))				sd = 1+(3*(j-1));
							else if	(tom <= 80+((j-1)*120))			sd = 2+(3*(j-1));
							else if	(tom <= 120+((j-1)*120)) 		sd = 3+(3*(j-1));
						}
						
						if(sd != 0) break;
					}
					
					for(int j=1;j<=sd;j++){
						md += "##";
					}
					
					//최초시작일과 시작일에 차이 계산후 넣을 변수
					int tofist =  fminute+(fhour*60);
					
					int toba = 0;				//"  "와 ##를 얼마큼 넣을지 수를 저장할 변수
					for(int j=1;j<=12;j++){		//월의 4주단위로 나눔 (월단위에 따라 j수가 증가)
						if(tofist <= 120*j){
							
							if	(tofist <= 40+((j-1)*120))			toba = 1+(3*(j-1));
							else if	(tofist <= 80+((j-1)*120))		toba = 2+(3*(j-1));
							else if	(tofist <= 120+((j-1)*120)) 		toba = 3+(3*(j-1));
						}
						if(toba != 0) break;
					}
					
					for(int j=1;j<=toba-1;j++){
						back += "  ";
						}			//주단위에서 #입력
					
					Arrayname.get(d).daywork.get(i).setJobday(back+md);
				}
			
				int[] day_h = {2,4,6,8,10,12};
				
				String[] am_pm = {"오전","오후"};
				String aa = " ";
				System.out.printf("\t\t|%19s%30s|",am_pm[0],aa);
				System.out.printf("%20s%28s|",am_pm[1],aa);
				
				System.out.println();
				System.out.printf("  스케줄  \t\t|");
				for(int j=0;j<am_pm.length;j++){
					for(int i=0;i<day_h.length;i++){
						System.out.printf("%5d|",day_h[i]);
					}
				}
				System.out.println();
				
				for(int j =0; j<Arrayname.get(d).daywork.size();j++){
					System.out.printf("%s\t\t|%s\n",Arrayname.get(d).daywork.get(j).getJob(), Arrayname.get(d).daywork.get(j).getJobday());
				}
			}
		}
		System.out.println();
	}
	
	public void DayWorkUpdate(){
		int cnt=0;
		System.out.println("===========하루일정 스케줄 수정==========");
		System.out.print("수정할 유저이름을 입력해주세요>");
		String name = sc.nextLine();
		for(int i=0; i<Arrayname.size(); i++){	//유저수만큼 반복
			if(Arrayname.get(i).getName().equals(name)){	//이름비교
				for(int j=0;j<Arrayname.get(i).daywork.size();j++){	//일정수만큼 반복
				System.out.println((cnt+1)+"."+Arrayname.get(i).daywork.get(cnt).toString());	//등록된 일정 출력
				cnt++;	//인덱스 증가
				}
			}
		}
			
		System.out.print("스케줄을 수정할 번호를 입력하세요>");
		int num=Integer.parseInt(sc.nextLine());

		for(int i=0; i<Arrayname.size(); i++){	//유저수만큼 반복
			if(Arrayname.get(i).getName().equals(name)){	//이름비교
				System.out.print("수정할 시작시간을 입력해주세요 ex)6:30 =");
				System.out.print(Arrayname.get(i).daywork.get(num-1).getFdate()+" >");
				Arrayname.get(i).daywork.get(num-1).setFdate(sc.nextLine());
				
				System.out.print("수정할 종료시간을 입력해주세요 ex)8:30 =");
				System.out.print(Arrayname.get(i).daywork.get(num-1).getLdate()+" >");
				Arrayname.get(i).daywork.get(num-1).setLdate(sc.nextLine());
				
				System.out.print("수정할 일정이 무엇입니까? =");
				System.out.print(Arrayname.get(i).daywork.get(num-1).getLdate()+" >");
				Arrayname.get(i).daywork.get(num-1).setJob(sc.nextLine());
								
				System.out.println("스케줄 등록이 완료 되었습니다.");
				System.out.println("");
			}
		}	
	}
	
	public void MonthWorkSearch() {	//달 스케줄 검색
        Calendar cal = Calendar.getInstance(); //캘린더 인스턴스 얻기
        System.out.println("==달 스케줄 검색==");
        System.out.print("달력을 검색할 유저를 입력하세요>");
        String name = sc.nextLine();
        int startday[]=new int[31];	//시작일 배열
        int endday[]=new int[31];	//종료일 배열
        
        for(int j=0; j<Arrayname.size(); j++){	//유저수만큼 반복
			if(Arrayname.get(j).getName().equals(name)){	//입력값과 유저이름 비교
				for(int i=0; i<Arrayname.get(j).monthwork.size(); i++){
					startday[i]=Arrayname.get(j).monthwork.get(i).getStartday();	//시작일 얻기
					endday[i]=Arrayname.get(j).monthwork.get(i).getEndday();	//종료일 얻기
					
					//원하는 년도 날짜 세팅 
			        cal.set(Calendar.YEAR, Arrayname.get(j).monthwork.get(i).getYear());
			        cal.set(Calendar.MONTH, Arrayname.get(j).monthwork.get(i).getMonth()-1);
				}
			}
			else { //이름이 잘못입력 됬을경우
				System.out.println("입력이 잘못 되었습니다.");
				break;
			}
 
        int sDayNum = cal.get(Calendar.DAY_OF_WEEK)-2; // 1일의 요일 얻어오기, SUNDAY (1) .MONDAY(2) , TUESDAY(3),.....
        int endDate = cal.getActualMaximum(Calendar.DATE); //달의 마지막일 얻기
        int nowYear = cal.get(Calendar.YEAR);	//입력한 년도 얻기
        int nowMonth = cal.get(Calendar.MONTH);	//입력한 달 얻기
        int sDay = sDayNum;
        
        //달력출력
        System.out.println("===================== "+ nowYear+"년  " + (nowMonth+1) + "월 ==================");
        //요일명 출력
        System.out.println(" 일\t 월\t 화\t 수\t 목\t 금\t 토\t");  
        System.out.println("====================================================");
        //1일이 시작되는 이전의 요일 공백으로 채우기 
        for (int i=1; i<sDayNum; i++){
            System.out.printf("%3s\t"," ");  
        }//for----------------- 
        int cnt=0;	//유저에 맞는 값을 얻어오기 위한 변수
        
        for (int i = 1; i <= endDate ; i++) {   // 1부터 마지막일까지 반복.
            if(i==startday[cnt]){	//시작일
            	if(startday[cnt]==endday[cnt]){	//시작일과 종료일이 같을때(하루일정)
            		System.out.printf("[%2d]\t",i);//일정이 하루일 경우 날짜 표시
            		cnt++;
            		sDay++;
            		continue;
            	}
            	System.out.printf("[%2d\t",i);  //일정 시작 날짜 표시
            }
            else if(i==endday[cnt]){//종료일
            	System.out.printf("%2d]\t",i);	//종료일 날짜 표시
            	cnt++;
            }
            else 
            	System.out.printf("%3d\t",i); //일정 없을 경우 출력

            if(sDay%7==0) System.out.println(); // 요일이 7배수가 되면 줄바꿈. 
            sDay++; //요일 카운트
        }
    }
        System.out.println();
        cnt=0;
        for(int j=0; j<Arrayname.size(); j++){	//등록된 전체 일정 표시
			if(Arrayname.get(j).getName().equals(name)){
				System.out.println("=====일정=====");
				for(int z=0; z<Arrayname.get(j).monthwork.size(); z++){
					System.out.println("("+Arrayname.get(j).monthwork.get(cnt).getStartday()+"~"
							+Arrayname.get(j).monthwork.get(cnt).getEndday()+")"+
							Arrayname.get(j).monthwork.get(cnt).getMwork());
					cnt++;
				}
				System.out.println();
			}
        }
	}
	

	public void MonthWorkUpdate(){	//유저의 달일정 수정
		cnt=0;
		System.out.println("==달 스케줄 수정==");
		System.out.print("유저를 입력하세요>");
		String name=sc.nextLine();
		for(int i=0; i<Arrayname.size(); i++){	//유저수만큼 반복
			if(Arrayname.get(i).getName().equals(name)){	//이름비교
				for(int j=0;j<Arrayname.get(i).monthwork.size();j++){	//일정수만큼 반복
					System.out.println((cnt+1)+"."+Arrayname.get(i).monthwork.get(cnt).toString());	//등록된 일정 출력
					cnt++;	//인덱스 증가
				}
			}
		}
		System.out.print("수정할 스케줄번호를 입력하세요>");
		int num=Integer.parseInt(sc.nextLine());
		
		for(int i=0; i<Arrayname.size(); i++){
			if(Arrayname.get(i).getName().equals(name)){
				
				System.out.print("달 "+Arrayname.get(i).monthwork.get(num-1).getMonth()+">");	//달일정 수정
				int month = Integer.parseInt(sc.nextLine());
				Arrayname.get(i).monthwork.get(num-1).setMonth(month);
				
				System.out.print("시작일 "+Arrayname.get(i).monthwork.get(num-1).getStartday()+">");	//시작일정 수정
				int startday=Integer.parseInt(sc.nextLine());
				Arrayname.get(i).monthwork.get(num-1).setStartday(startday);
	
				System.out.print("종료일 "+Arrayname.get(i).monthwork.get(num-1).getEndday()+">");	//종료일정 수정
				int endday=Integer.parseInt(sc.nextLine());
				Arrayname.get(i).monthwork.get(num-1).setEndday(endday);
				
				System.out.print("할일 "+Arrayname.get(i).monthwork.get(num-1).getMwork()+">");	//일정내용 수정
				String mwork=sc.nextLine();
				Arrayname.get(i).monthwork.get(num-1).setMwork(mwork);
				
				System.out.println("수정이 완료 되었습니다.");
				System.out.println("");
			}
		}	
	}
	
	public void MonthworkDelete(){	//달 스케줄 삭제
		cnt=0;
		System.out.println("==달 스케줄 삭제==");
		System.out.print("유저를 입력하세요>");
		String name=sc.nextLine();
		for(int i=0; i<Arrayname.size(); i++){	//유저에 해당하는 모든 달 일정 표시
			if(Arrayname.get(i).getName().equals(name)){
				for(int j=0;j<Arrayname.get(i).monthwork.size();j++){
					System.out.println((cnt+1)+"."+Arrayname.get(i).monthwork.get(cnt).toString());
					cnt++;
				}
			}
		}
		System.out.print("스케줄번호를 입력하세요>");
		int num=Integer.parseInt(sc.nextLine());
		
		for(int i=0; i<Arrayname.size(); i++){	//달 스케줄 삭제
			if(Arrayname.get(i).getName().equals(name)){
				Arrayname.get(i).monthwork.remove(num-1);	//인덱스에 해당하는 스케줄 삭제
			
				System.out.println(num+"번째 스케줄 삭제되었습니다.");
				System.out.println("");
			}
			else
				System.out.println("입력이 잘못 되었습니다.");
		}
	}
	public void DayworkDelete(){	//일 스케줄 삭제
		cnt=0;
		System.out.println("==일 스케줄 삭제==");
		System.out.print("유저를 입력하세요>");
		String name=sc.nextLine();
		for(int i=0; i<Arrayname.size(); i++){	//일 전체 스케줄 표시
			if(Arrayname.get(i).getName().equals(name)){
				for(int j=0;j<Arrayname.get(i).daywork.size();j++){
					System.out.println((cnt+1)+"."+Arrayname.get(i).daywork.get(cnt).toString());
					cnt++;
				}
			}
		}
		System.out.print("스케줄번호를 입력하세요>");
		int num=Integer.parseInt(sc.nextLine());
		
		for(int i=0; i<Arrayname.size(); i++){
			if(Arrayname.get(i).getName().equals(name)){
				Arrayname.get(i).daywork.remove(num-1);	//num에 해당하는 일 스케줄 삭제
			
				System.out.println(num+"번째 스케줄 삭제되었습니다.");
				System.out.println("");
			}
			else
				System.out.println("입력이 잘못 되었습니다.");
		}
	}
}
	