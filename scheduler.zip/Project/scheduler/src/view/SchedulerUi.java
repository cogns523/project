package view;

public class SchedulerUi {
	public void ShowMenu(){	//기본 메뉴
		System.out.println("=============");
		System.out.println("1.스케줄 등록");
		System.out.println("2.스케줄 검색");
		System.out.println("3.스케줄 수정");
		System.out.println("4.스케줄 삭제");
		System.out.println("5.프로그램 종료");
		System.out.println("=============");
		System.out.print("선택=");
	}
	
	public void ScheduleInsertMenu(){	//스케줄에 따른 등록메뉴
		System.out.println("=============");
		System.out.println("1.개인 스케줄 등록");
		System.out.println("2.근무표 등록");
		System.out.println("3.프로젝트 등록");
		System.out.println("4.취소");
		System.out.println("=============");
		System.out.print("선택=");
	}
	
	public void UserMenu(){	//유저등록 메뉴
		System.out.println("=============");
		System.out.println("1.유저 등록");
		System.out.println("2.스케줄 추가");
		System.out.println("3.취소");
		System.out.println("=============");
		System.out.print("선택=");
	}
	
	public void WorkInsertMenu(){	//일정 등록메뉴
		System.out.println("=============");
		System.out.println("1.월 스케줄 등록");
		System.out.println("2.일 스케줄 등록");
		System.out.println("3.취소");
		System.out.println("=============");
		System.out.print("선택=");
	}
	
	public void ScheduleSearchMenu(){  //스케줄 검색 메뉴
		System.out.println("=============");
		System.out.println("1.개인 스케줄 검색");
		System.out.println("2.근무표 검색");
		System.out.println("3.프로젝트 검색");
		System.out.println("4.취소");
		System.out.println("=============");
		System.out.print("선택=");
	}
	
	public void UserSearchMenu(){ //유저 선택
		System.out.println("=============");
		System.out.println("1.유저 선택");
		System.out.println("2.취소");
		System.out.println("=============");
		System.out.print("선택=");
	}
	
	public void WorkSearchMenu(){	//일정 검색 메뉴
		System.out.println("=============");
		System.out.println("1.월 스케줄 검색");
		System.out.println("2.일 스케줄 검색");
		System.out.println("3.취소");
		System.out.println("=============");
		System.out.print("선택=");
	}
	
	public void ScheduleUpdateMenu(){	//스케줄에 따른 수정 메뉴
		System.out.println("=============");
		System.out.println("1.개인 스케줄 수정");
		System.out.println("2.근무표 수정");
		System.out.println("3.프로젝트 수정");
		System.out.println("4.취소");
		System.out.println("=============");
		System.out.print("선택=");
	}
	
	public void WorkUpdateMenu(){	//일정 수정 메뉴
		System.out.println("=============");
		System.out.println("1.월 스케줄 수정");
		System.out.println("2.일 스케줄 수정");
		System.out.println("3.취소");
		System.out.println("=============");
		System.out.print("선택=");
	}
	
	public void ScheduleDeleteMenu(){	//스케줄에 따른 삭제 메뉴
		System.out.println("=============");
		System.out.println("1.개인 스케줄 삭제");
		System.out.println("2.근무표 삭제");
		System.out.println("3.프로젝트 삭제");
		System.out.println("4.취소");
		System.out.println("=============");
		System.out.print("선택=");
	}
	
	public void WorkDeleteMenu(){	//일정 삭제 메뉴
		System.out.println("=============");
		System.out.println("1.월 스케줄 삭제");
		System.out.println("2.일 스케줄 삭제");
		System.out.println("3.취소");
		System.out.println("=============");
		System.out.print("선택=");
	}
}
