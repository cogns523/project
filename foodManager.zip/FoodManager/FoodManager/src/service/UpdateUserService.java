package service;

import DAO.DAO;
import model.UserInfo;
/*
 * ���� ��ü �ҷ����ų� �� ����
 */
public class UpdateUserService {
	UserInfo a=null;
	
	//id������ ������ü ������ ����
	public UserInfo getOldUser(String id) {
		DAO dao=new DAO();
		UserInfo oldUser=dao.UpdateOldUser(id);
		
		return oldUser;
	}
	
	public boolean modifyKcal(UserInfo updateUser) {
		boolean isUpdate=false;
		
		DAO dao=new DAO();
		int updateCount=dao.updateKcal(updateUser.getId(),
										updateUser.getKcal(),
										updateUser.getWantKcal(),
										updateUser.getStandardweight(),
										updateUser.getDietStandardWeight());
		if(updateCount>0) isUpdate=true;
		
		return isUpdate;
				
	}
	
	public boolean modifyWeight(String id, int weight) {
		boolean isUpdate=false;
		
		DAO dao=new DAO();
		int updateCount=dao.updateWeight(id, weight);
		if(updateCount>0) isUpdate=true;
		
		return isUpdate;
				
	}
}
