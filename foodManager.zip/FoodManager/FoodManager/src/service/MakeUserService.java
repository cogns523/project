package service;

import static db.JdbcUtils.close;
import static db.JdbcUtils.getConnection;
import static db.JdbcUtils.rollback;

import java.sql.Connection;

import DAO.DAO;
import model.UserInfo;
/*
 * ���� ��� �ϱ����� Ŭ����
 */
public class MakeUserService {
	public boolean addUser(UserInfo user){
		boolean isInsertSuccess=false;
		Connection conn=getConnection();
		
		DAO dao=new DAO();
		int insertCount = dao.insertNewUser(user);
		
		if(insertCount>0){
			isInsertSuccess=true;
		} else {
			rollback(conn);
		}
		close(conn);
		return isInsertSuccess;
	}
}
