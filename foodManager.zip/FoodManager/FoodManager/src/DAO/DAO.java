package DAO;
import static db.JdbcUtils.close;
import static db.JdbcUtils.getConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import model.UserInfo;
/*
 * SQL�� ����
 */
public class DAO {
	Connection conn=null;
	//db����
	public DAO(){
		conn=getConnection();
	}
	
	//�������
	public int insertNewUser(UserInfo user) {
		int insertCount=0;
		PreparedStatement pstmt=null;
		String sql="insert into UserInfo values(?,?,?,?,?,?,?,?,?,?,?,?,?)";

		try {
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, user.getId());
			pstmt.setString(2, user.getPass());
			pstmt.setString(3, user.getName());
			pstmt.setInt(4, user.getAge());
			pstmt.setInt(5, user.getHeight());
			pstmt.setInt(6, user.getWeight());
			pstmt.setString(7, user.getSex());
			pstmt.setString(8, user.getUserlevel());
			pstmt.setString(9, user.getWant());
			pstmt.setInt(10, user.getKcal());
			pstmt.setInt(11, user.getWantKcal());
			pstmt.setInt(12, user.getStandardweight());
			pstmt.setInt(13, user.getDietStandardWeight());
			insertCount=pstmt.executeUpdate();	//���� �޶����� ������Ų��.

		}catch(SQLException e) {
			e.printStackTrace();
		} finally {
			close(pstmt);
		}
		return insertCount;
	}
	
	//Į�θ� ������Ʈ
	public int updateKcal(String id, int Kcal, int WantKcal, int Standardweight, int DietStandardweight) {
		int updateCount=0;
		String sql="update UserInfo set Kcal=?, WantKcal=?, Standardweight=?, DietStandardweight=? where id=?";
		PreparedStatement pstmt=null;
		
		try{
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, Kcal);
			pstmt.setInt(2, WantKcal);
			pstmt.setInt(3, Standardweight);
			pstmt.setInt(4, DietStandardweight);
			pstmt.setString(5, id);
			
			updateCount=pstmt.executeUpdate();
		} catch(SQLException e) {
			e.printStackTrace();
		} finally {
			close(pstmt);
		}
		
		return updateCount;
	}
	
	//����� ������ü �ҷ�����
	public UserInfo UpdateOldUser(String id){
		UserInfo oldUser=null;
		String sql="select * from UserInfo where id=?";
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		
		try{
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, id);
			
			rs=pstmt.executeQuery();
			if(rs.next()){
				oldUser=new UserInfo(
					rs.getString("id"),
					rs.getString("pass"),
					rs.getString("name"),
					rs.getInt("age"),
					rs.getInt("height"),
					rs.getInt("weight"),
					rs.getString("sex"),
					rs.getString("userlevel"),
					rs.getString("want"),
					rs.getInt("Kcal"),
					rs.getInt("WantKcal"),
					rs.getInt("Standardweight"),
					rs.getInt("DietStandardweight"));
			} else {
				oldUser=new UserInfo("","");
				return oldUser;
			}
		} catch(SQLException e) {
			e.printStackTrace();
		}finally{
			close(rs);
			close(pstmt);
		}	
		return oldUser;
	}
	
	//ü�߼���
	public int updateWeight(String id, int weight) {
		int updateCount=0;
		String sql="update UserInfo set weight=? where id=?";
		PreparedStatement pstmt=null;
		
		try{
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, weight);
			pstmt.setString(2, id);
			
			updateCount=pstmt.executeUpdate();
		} catch(SQLException e) {
			e.printStackTrace();
		} finally {
			close(pstmt);
		}
		
		return updateCount;
	}
	
	//ȸ����ü id �ҷ�����
	public ArrayList findId() {
		String sql="select id from UserInfo";
		ArrayList allId=null;
		Statement stmt=null;
		ResultSet rs=null;
		
		try {
			stmt=conn.createStatement();
			rs=stmt.executeQuery(sql);
			allId=new ArrayList();
			int i=0;
			
			if(rs.next()){
				allId.add(rs.getString("id"));
			}
			
		} catch(SQLException e) {
			e.printStackTrace();
		}
		return allId;
	}
}
